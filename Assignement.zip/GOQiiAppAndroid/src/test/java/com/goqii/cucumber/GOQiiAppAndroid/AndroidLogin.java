package com.goqii.cucumber.GOQiiAppAndroid;

import java.io.File;
import java.io.FileInputStream;
import java.net.URL;
import java.time.Duration;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.remote.DesiredCapabilities;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class AndroidLogin {

	public static AndroidDriver<MobileElement> driver = null;
	public Properties prop;
	public FileInputStream fs;
	public Dimension size;

	@Given("^i want to open swaglabs app$")
	public void i_want_to_open_goqii_app() throws Throwable {
		prop = new Properties();
		String path = System.getProperty("user.dir") + "//src//test//resources//project.properties";

		fs = new FileInputStream(path);
		prop.load(fs);
		File app = new File(prop.getProperty("apkPath"));
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("deviceName", prop.getProperty("deviceName"));
		caps.setCapability("udid", prop.getProperty("udid"));
		caps.setCapability("platformName", prop.getProperty("platformName"));
		caps.setCapability("platformVersion", prop.getProperty("platformVersion"));

		caps.setCapability("appActivity", prop.getProperty("appActivity"));
		caps.setCapability("appPackage", prop.getProperty("appPackage"));

		caps.setCapability("app", app.getAbsolutePath());
		caps.setCapability("noReset", "false");
		caps.setCapability("autoGrantPermission", "true");
		driver = new AndroidDriver<MobileElement>(new URL(prop.getProperty("hubURL")), caps);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

	}

	@When("^i want to login to app with registered user$")
	public void Login_to_app() {
		driver.findElement(By.xpath(prop.getProperty("username_input_xpath"))).click();
		driver.findElement(By.xpath(prop.getProperty("username_input_xpath"))).sendKeys(prop.getProperty("username"));
		// driver.hideKeyboard();
		driver.findElement(By.xpath(prop.getProperty("password_input_xpath"))).click();

		driver.findElement(By.xpath(prop.getProperty("password_input_xpath"))).sendKeys(prop.getProperty("password"));
		driver.findElement(By.xpath(prop.getProperty("login_btn_xpath"))).click();
		driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);

	}

	@Then("^user should login sucessfull$")
	public void user_login() throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);

		MobileElement element = (MobileElement) driver.findElement(By.xpath(prop.getProperty("cart_btn_xpath")));
		boolean isDisplayed = element.isDisplayed();
		System.out.println("Element Display:-" + isDisplayed);

		if (isDisplayed == true) {
			System.out.println("Login Sucessfull");
		} else {
			System.out.println("Login unsucessfull");

		}

	}

	@And("user add products to cart")
	public void user_add_products_to_cart() {
		driver.findElement(By.xpath(prop.getProperty("Selectproduct1_btn_xpath"))).click();
		// driver.findElement(By.xpath(prop.getProperty("Selectproduct2_btn_xpath"))).click();

	}

	@Then("product should get added to cart")
	public void product_should_get_removed_from_cart() {

		driver.findElement(By.xpath(prop.getProperty("cart_btn_xpath"))).click();

		String prodcutnamefromlist = driver.findElement(By.xpath(prop.getProperty("product_name_bags_xpath")))
				.getText();

		String prodcutnameoncart = driver.findElement(By.xpath(prop.getProperty("cart_name_bags_xpath"))).getText();

		if (prodcutnamefromlist.equals(prodcutnameoncart)) {
			System.out.println("Product sucessfully added on cart");
		} else {
			System.out.println("Product is not added on cart");

		}

	}

	@And("user delete products from cart")
	public void user_delete_products_from_cart() {
		driver.findElement(By.xpath(prop.getProperty("cart_remove_product_xpath"))).click();

	}

	@Then("prodcuts should get deleted from cart")
	public void prodcuts_should_get_delete_from_cart() {
		String prodcutsincart = "0";
		if (driver.findElement(By.xpath(prop.getProperty("cart_btn_xpath"))).getText().equals(prodcutsincart)) {
			System.out.println("Products removed sucessfully");

		} else {
			System.out.println("Products removed sucessfully");

		}
	}

	@And("again user add products to cart")
	public void again_user_add_products_to_cart() {
		driver.findElement(By.xpath(prop.getProperty("cart_continuebtn_xpath"))).click();
		driver.findElement(By.xpath(prop.getProperty("Selectproduct1_btn_xpath"))).click();

	}

	@Then("again product should get added to cart")
	public void again_product_should_get_added_to_cart() {
		driver.findElement(By.xpath(prop.getProperty("cart_btn_xpath"))).click();

		String prodcutnamefromlist = driver.findElement(By.xpath(prop.getProperty("product_name_bags_xpath")))
				.getText();

		String prodcutnameoncart = driver.findElement(By.xpath(prop.getProperty("cart_name_bags_xpath"))).getText();

		if (prodcutnamefromlist.equals(prodcutnameoncart)) {
			System.out.println("Product sucessfully added on cart");
		} else {
			System.out.println("Product is not added on cart");

		}

	}

	@Then("user navigates to checkout and fill all delivery information details")
	public void user_navigates_to_checkout_and_fill_all_delivery_information_details() {

		driver.findElement(By.xpath(prop.getProperty("cart_checkoutbtn_xpath"))).click();

		driver.findElement(By.xpath(prop.getProperty("checkout_infofirstname_xpath"))).sendKeys("Dinesh");
		driver.findElement(By.xpath(prop.getProperty("checkout_infolastname_xpath"))).sendKeys("Patil");
		driver.findElement(By.xpath(prop.getProperty("checkout_infopostalcode_xpath"))).sendKeys("400008");

	}

	@Then("user click on continue and navigate to checkout:overview page, verifies the details")
	public void user_click_on_continue_and_navigate_to_checkout_overview_page_verifies_the_details() {
		driver.findElement(By.xpath(prop.getProperty("checkout_continuebtn_xpath"))).click();
		String prodcutnamefromlist = driver.findElement(By.xpath(prop.getProperty("cart_producttext_xpath"))).getText();

		String prodcutnameoncart = driver.findElement(By.xpath(prop.getProperty("cart_producttext_xpath"))).getText();

		if (prodcutnamefromlist.equals(prodcutnameoncart)) {
			System.out.println("Product dispklayed on checkout overview");
		} else {
			System.out.println("Product is present");

		}

	}

	@Then("user tap on finish and user should show success message of checkout successful")
	public void user_tap_on_finish_and_user_should_show_success_message_of_checkout_successful() {

		TouchAction action = new TouchAction(driver);
		Dimension size = driver.manage().window().getSize();
		int width = size.width;
		int height = size.height;
		int middleOfX = width / 2;
		int startYCoordinate = (int) (height * .7);
		int endYCoordinate = (int) (height * .2);

		action.press(PointOption.point(middleOfX, startYCoordinate))
				.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(2)))
				.moveTo(PointOption.point(middleOfX, endYCoordinate)).release().perform();

		driver.findElement(By.xpath(prop.getProperty("checkout_overviewfinish_xpath"))).click();
		String Ordersucess = "THANK YOU FOR YOU ORDER";
		String actualtext = driver.findElement(By.xpath(prop.getProperty("checkout_complele_xpath"))).getText();

		if (Ordersucess.equals(actualtext)) {
			System.out.println("Order sucess");
		} else {
			System.out.println("Order unsucessfull");
		}

	}

}
